package com.example.hw3test1

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import android.Manifest
import java.io.File
import java.io.FileOutputStream

class BlurWorker(appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {

        val imageUri = inputData.getString("imageUri") ?: return Result.failure()

        val blurredBitmap = blurImage(applicationContext, Uri.parse(imageUri))

        val outputUri = saveImage(blurredBitmap)

        if (ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            sendNotification(outputUri.toString())
        } else {
            return Result.failure()
        }

        return Result.success()

    }

    private suspend fun blurImage(context: Context, uri: Uri): Bitmap {

        val loader = ImageLoader(context)
        val request = ImageRequest.Builder(context)
            .data(uri)
            .allowHardware(false)
            .build()

        val result = (loader.execute(request = request) as SuccessResult).drawable
        val bitmap = (result as BitmapDrawable).bitmap

        val outputBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)

        return outputBitmap

    }

    private fun saveImage(bitmap: Bitmap): Uri {

        val file = File(applicationContext.externalCacheDir, "blurred_image.jpg")
        val outputStream = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
        outputStream.flush()
        outputStream.close()
        return Uri.fromFile(file)

    }

    private fun sendNotification(imageUri: String) {

        val context = applicationContext
        val channelId = "blur_worker_channel"
        val notificationId = 1

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Blur Worker"
            val descriptionText = "Notification for Blur Worker"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.important_notification)
            .setContentTitle("Image Blurred")
            .setContentText("Image has been blurred successfully. Tap to view.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setStyle(NotificationCompat.BigPictureStyle().bigPicture(BitmapFactory.decodeFile(imageUri)))

        val notificationPermission = Manifest.permission.POST_NOTIFICATIONS
        if (ContextCompat.checkSelfPermission(context, notificationPermission) == PackageManager.PERMISSION_GRANTED) {
            with(NotificationManagerCompat.from(context)) {
                notify(notificationId, builder.build())
            }
        } else {
            Toast.makeText(context, "Notification Permission Denied", Toast.LENGTH_SHORT).show()
        }

    }




}